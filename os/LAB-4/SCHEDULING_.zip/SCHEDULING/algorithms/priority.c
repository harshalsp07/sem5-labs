#include "../simulator.h"

int priority_scheduler(Simulation *sim)
{
    int selected = -1;

    for (int i = 0; i < sim->process_count; i++) {

        Process *p = &sim->processes[i];

        if (p->state == READY) {

            if (selected == -1 ||
                p->priority <
                sim->processes[selected].priority) {

                selected = i;
            }
        }
    }

    return selected;
}
